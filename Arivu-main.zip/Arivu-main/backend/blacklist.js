const blacklist = [];

module.exports = {
  blacklist,
};
